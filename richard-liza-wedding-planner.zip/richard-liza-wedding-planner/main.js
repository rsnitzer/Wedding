// Countdown to Dec 31, 2026
const targetDate = new Date("2026-12-31T00:00:00");

function updateCountdown() {
  const el = document.getElementById("countdown-timer");
  if (!el) return;
  const now = new Date();
  const diffMs = targetDate.getTime() - now.getTime();
  if (diffMs <= 0) {
    el.textContent = "It's your wedding date!";
    return;
  }
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diffMs / (1000 * 60 * 60)) % 24);
  const mins = Math.floor((diffMs / (1000 * 60)) % 60);
  el.textContent = `${days} days, ${hours} hours, ${mins} minutes`;
}

updateCountdown();
setInterval(updateCountdown, 60000);

document.querySelectorAll(".splash-nav button").forEach((btn) => {
  btn.addEventListener("click", () => {
    const view = btn.getAttribute("data-nav");
    alert(`In the full app, this would open the "${view}" screen.`);
  });
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/service-worker.js")
      .catch((err) => console.error("SW registration failed:", err));
  });
}
