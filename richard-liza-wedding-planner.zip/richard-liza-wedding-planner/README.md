# Richard & Liza Wedding Planner

Netlify-ready Vite + vanilla JavaScript PWA starter.

## Local development

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Deploy

Upload this repository to Netlify. The included `netlify.toml` publishes the Vite build output from `dist`.

## Next expansion targets

- Calendar
- Timeline
- Create Event
- Tasks
- Parking Lot
- People
- Reports
- Local storage persistence
